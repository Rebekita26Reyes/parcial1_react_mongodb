import React from 'react';

const TaskItem = ({ task, toggleTask, deleteTask }) => {
  return (
    <li>
      <input
        type="checkbox"
        checked={task.done}
        onChange={() => toggleTask(task._id)}
      />
      <span>{task.name}</span>
      <button onClick={() => deleteTask(task._id)}>
      <i class="bi bi-trash3-fill"></i>Eliminar</button>
    </li>
  );
};

export default TaskItem;