import React from 'react';

const TaskCard = ({ task }) => {
  return (
    <div className="card" style={{ width: '18rem' }}>
      <div className="card-body">
        <h5 className="card-title">{task.name}</h5>
        <p className="card-text">Status: {task.done ? 'Completada' : 'Pendiente'}</p>
        {/* Botones de acciones (marcar como completada, eliminar, etc.) */}
      </div>
    </div>
  );
};

export default TaskCard;