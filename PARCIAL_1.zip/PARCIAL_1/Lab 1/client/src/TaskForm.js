import React, { useState } from 'react';
import axios from 'axios';

const TaskForm = ({ addTask }) => {
  const [newTask, setNewTask] = useState('');

  const handleAddTask = async () => {
    if (newTask.trim() !== '') {
      try {
        const response = await axios.post('http://localhost:5000/tasks', {
            
          name: newTask,
        });
        addTask(response.data); 
        setNewTask('');
      } catch (error) {
        console.error('Error adding task:', error);
      }
    }
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Introduzca una nueva tarea"
        value={newTask}
        onChange={(e) => setNewTask(e.target.value)}
      />
      <button onClick={handleAddTask}>Add Task</button>
    </div>
  );
};

export default TaskForm;
