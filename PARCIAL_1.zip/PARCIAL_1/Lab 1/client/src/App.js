import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './style.css';

const TaskItem = ({ task, toggleTask, deleteTask }) => {
  const taskStyle = {
    textDecoration: task.done ? 'line-through' : 'none', // Usamos 'line-through' para tareas completadas
  };

  const buttonStyle = {
    fontSize: '12px', // Tamaño de fuente más pequeño
  };

  return (
    <div className="task-box">
      <span className="task-text" style={taskStyle}>
        {task.name}
      </span>
      <div className="task-buttons">
        <button className="complete-button" style={buttonStyle} onClick={() => toggleTask(task._id)}>
        <i class="bi bi-check-circle"></i>
          Completada
        </button> 
        <button className="delete-button"  style={buttonStyle} onClick={() => deleteTask(task._id)}>
        <i class="bi bi-trash3-fill"></i>
          Eliminar
          
        </button>
      </div>
    </div>
  );
};

const App = () => {
  const [taskItems, setTaskItems] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [completedTasks, setCompletedTasks] = useState(0);
  const [pendingTasks, setPendingTasks] = useState(0);

  useEffect(() => {
    fetchTasks();
  }, []);

  useEffect(() => {
    const completed = taskItems.filter(task => task.done).length;
    setCompletedTasks(completed);
    setPendingTasks(taskItems.length - completed);
  }, [taskItems]);

  const fetchTasks = async () => {
    try {
      const response = await axios.get('http://localhost:5000/tasks');
      setTaskItems(response.data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  const addTask = async () => {
    if (newTask.trim() !== '') {
      try {
        const response = await axios.post('http://localhost:5000/tasks', {
          name: newTask,
        });
        setTaskItems([...taskItems, response.data]);
        setNewTask('');
      } catch (error) {
        console.error('Error adding task:', error);
      }
    }
  };

  const toggleTask = async (id) => {
    const updatedTasks = [...taskItems];
    const taskToUpdate = updatedTasks.find(task => task._id === id);
    taskToUpdate.done = !taskToUpdate.done;

    try {
      await axios.put(`http://localhost:5000/tasks/${id}`, taskToUpdate);
      setTaskItems(updatedTasks);
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  const deleteTask = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/tasks/${id}`);
      const updatedTasks = taskItems.filter(task => task._id !== id);
      setTaskItems(updatedTasks);
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  };

  const deleteAllTasks = async () => {
    try {
      await axios.delete('http://localhost:5000/tasks');
      setTaskItems([]);
    } catch (error) {
      console.error('Error deleting all tasks:', error);
    }
  };

  return (
    <div className="App">
      <header>
        <h1>LISTA DE TAREAS</h1> <i class="bi bi-list-task"></i>
      </header>
      <main>
        <input
          type="text"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)} 
          placeholder="Introduzca una nueva tarea"
          className="input-task"
        />
        <button onClick={addTask} className=" add-button btn btn-outline-primary">
        <i class="bi bi-save"></i>
  Guardar
</button>
{taskItems.length > 0 && (
  <button onClick={deleteAllTasks} className="delete-all-button btn btn-danger">
    Eliminar todas
  </button>
)}
       
        <div>
          <p>Completadas: {completedTasks}</p>
          <p>Pendientes: {pendingTasks}</p>
        </div>
        <div className="task-list">
          {taskItems.map(task => (
            <TaskItem
              key={task._id}
              task={task}
              toggleTask={toggleTask}
              deleteTask={deleteTask}
            />
          ))}
        </div>
      </main>
    </div>
  );
};

export default App;
